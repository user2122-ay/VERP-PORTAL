"use client";
import { useState, useEffect } from "react";
import { Search, Plus, Trash2, Skull, Check } from "lucide-react";
import { canAdmin, RANK_LABEL } from "@/lib/roles";
import { RANGOS_POR_DEPTO, DEPTOS } from "@/lib/mdt";
const CATS = ["Concesionario", "Propiedades", "Licencias", "Objetos", "Armas", "Herramientas", "Telefonía", "Tecnología"], INV = ["Banco", "Telefonía", "Tecnología", "Propiedades", "Concesionario", "Herramientas", "Objetos", "Armas", "Licencias"], CIVIL = ["SOLTERO", "CASADO", "DIVORCIADO", "VIUDO"];
const BK = { bvc: "BVC", mer: "Mercantil VERP", pro: "Provincial", ven: "VERNESCO", vca: "VERCARIBE", com: "Comerciante" }, $ = (n) => `$${Number(n || 0).toLocaleString("es")}`;
const post = async (a, data) => { const r = await fetch("/api/admin", { method: "POST", body: JSON.stringify({ a, ...data }) }), j = await r.json().catch(() => ({})); if (!r.ok) { alert(j.error || "Error"); return false; } return true; };
const vals = (e) => { e.preventDefault(); return Object.fromEntries(new FormData(e.target, e.nativeEvent?.submitter)); };
const ask = (t) => { const r = prompt(t); if (r === null) return null; if (r.trim().length < 3) { alert("La razón es obligatoria (mínimo 3 letras)"); return null; } return r.trim(); };
const Razon = () => <input name="razon" placeholder="Razón (obligatoria)" required minLength={3} />;
function Usuarios({ items }) {
  const [q, setQ] = useState(""), [res, setRes] = useState(null), [u, setU] = useState(null), [cat, setCat] = useState("Banco");
  const abrir = async (id) => { const r = await fetch("/api/admin?uid=" + encodeURIComponent(id)); if (r.ok) setU((await r.json()).user); };
  const buscar = async (e) => { e.preventDefault(); const r = await fetch("/api/admin?q=" + encodeURIComponent(q)); if (r.ok) setRes((await r.json()).users); };
  const act = async (a, data) => { if (await post(a, { uid: u.id, ...data })) { alert("Listo"); if (a === "ck") { setU(null); setRes(null); } else abrir(u.id); } };
  const quick = (a, data, t) => { const r = ask(t); if (r) act(a, { ...data, razon: r }); };
  const c = u?.cedula, banks = u ? Object.keys(u.cuentas) : [], lista = u ? u.inventory.filter((i) => i.category === cat) : [], cat_items = items.filter((i) => i.category === cat);
  return (<>
    <form className="card" onSubmit={buscar} style={{ display: "flex", gap: 8 }}><input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Buscar por usuario de Discord, Roblox, nombre, cédula o ID" style={{ flex: 1 }} /><button className="btn"><Search size={18} />Buscar</button></form>
    {res && !res.length && <p className="mut">Sin resultados.</p>}
    {res && res.map((x) => <div key={x.id} className="card" style={{ cursor: "pointer", marginTop: 8 }} onClick={() => abrir(x.id)}><b>{x.name}</b> <span className="mut">{x.cedula ? `${x.cedula.nombres} ${x.cedula.apellidos} · V-${String(x.cedula.num).padStart(8, "0")} · ${x.cedula.roblox}` : "Sin cédula"}</span></div>)}
    {u && <div style={{ display: "grid", gap: 12, marginTop: 12 }}>
      <div className="card"><b>{u.name}</b> <span className="mut">ID {u.id}{u.chip ? ` · Línea ${u.chip}` : ""}</span><div>Efectivo {$(u.balance)}{banks.map((k) => ` · ${BK[k]} ${$(u.cuentas[k].saldo)}`)}</div></div>
      {c && <form className="card" onSubmit={(e) => { const v = vals(e); act("editCedula", { cedula: { nombres: v.nombres, apellidos: v.apellidos, edoCivil: v.edoCivil, lugar: v.lugar, roblox: v.roblox, nac: v.nac }, razon: v.razon }); }}><b>Editar cédula</b>
        <input name="nombres" defaultValue={c.nombres} placeholder="Nombres" /><input name="apellidos" defaultValue={c.apellidos} placeholder="Apellidos" /><input name="nac" type="date" defaultValue={c.nac ? String(c.nac).slice(0, 10) : ""} />
        <select name="edoCivil" defaultValue={c.edoCivil}>{[...new Set([c.edoCivil, ...CIVIL])].map((x) => <option key={x}>{x}</option>)}</select><input name="lugar" defaultValue={c.lugar} placeholder="Lugar de nacimiento" /><input name="roblox" defaultValue={c.roblox} placeholder="Usuario de Roblox" /><Razon /><button className="btn">Guardar cambios</button></form>}
      <form className="card" onSubmit={(e) => act("dinero", vals(e))}><b>Dinero</b><select name="destino"><option value="efectivo">Efectivo</option>{banks.map((k) => <option key={k} value={k}>Cuenta {BK[k]}</option>)}</select><input name="monto" type="number" min="1" placeholder="Monto" required /><Razon />
        <div style={{ display: "flex", gap: 8 }}><button className="btn" name="tipo" value="agregar" style={{ flex: 1 }}>Agregar</button><button className="btn r" name="tipo" value="quitar" style={{ flex: 1 }}>Retirar</button></div></form>
      <div className="card"><b>Inventario</b><div style={{ display: "flex", gap: 6, flexWrap: "wrap", margin: "8px 0" }}>{INV.map((x) => <button key={x} className={"btn " + (cat === x ? "" : "g")} onClick={() => setCat(x)}>{x}</button>)}</div>
        {cat === "Banco" ? Object.keys(BK).map((k) => <div key={k} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", margin: "6px 0" }}>{u.cuentas[k] ? <><span>{BK[k]} <span className="mut">saldo {$(u.cuentas[k].saldo)}</span></span><button className="btn g" onClick={() => quick("cuentaQuitar", { banco: k }, `Razón para quitar la tarjeta ${BK[k]}:`)}><Trash2 size={16} />Quitar</button></>
          : <><span className="mut">{BK[k]}: no la tiene</span><button className="btn g" onClick={() => quick("cuentaDar", { banco: k }, `Razón para dar la tarjeta ${BK[k]}:`)}><Plus size={16} />Dar tarjeta</button></>}</div>) : <>
          {cat === "Telefonía" && <><div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", margin: "6px 0" }}>{u.chip ? <><span>Chip {u.chip}</span><button className="btn g" onClick={() => quick("chipQuitar", {}, "Razón para quitar el chip:")}><Trash2 size={16} />Quitar</button></> : <><span className="mut">Sin chip</span><button className="btn g" onClick={() => quick("chipDar", {}, "Razón para dar un chip:")}><Plus size={16} />Dar chip</button></>}</div>
            {u.plan && <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", margin: "6px 0" }}><span>Plan {$(u.plan.monto)}/semana</span><button className="btn g" onClick={() => quick("planQuitar", {}, "Razón para cancelar el plan:")}><Trash2 size={16} />Cancelar</button></div>}</>}
          {lista.map((i, k) => <div key={k} style={{ display: "flex", justifyContent: "space-between", gap: 8, alignItems: "center", margin: "6px 0" }}><span>{i.name} <span className="mut">{$(i.price)}</span></span><button className="btn g" onClick={() => quick("invQuitar", { name: i.name, at: i.at }, `Razón para quitar "${i.name}":`)}><Trash2 size={16} />Quitar</button></div>)}
          {!lista.length && <p className="mut">No tiene nada en {cat}.</p>}
          {cat_items.length > 0 && <form onSubmit={(e) => act("invAgregar", vals(e))} style={{ display: "grid", gap: 8, marginTop: 8 }}><select name="itemId">{cat_items.map((i) => <option key={i.id} value={i.id}>{i.name}{i.ubicacion ? ` · ${i.ubicacion}` : ""} · {$(i.price)}</option>)}</select><Razon /><button className="btn g"><Plus size={16} />Agregar al inventario</button></form>}</>}</div>
      <form className="card" style={{ borderColor: "var(--bad)" }} onSubmit={(e) => { if (!confirm("CK: se borra TODO de este usuario, incluida la cédula. ¿Continuar?")) return e.preventDefault(); act("ck", vals(e)); }}><b style={{ color: "var(--bad)" }}>CK (character kill)</b>
        <p className="mut">Borra cédula, efectivo, cuentas, inventario, línea, chats y estados. El usuario podrá registrar un personaje nuevo.</p><input name="confirm" placeholder='Escribe "CK" para confirmar' required /><Razon /><button className="btn r"><Skull size={16} />Aplicar CK</button></form></div>}</>);
}
function Mercado({ items }) {
  const [cat, setCat] = useState(CATS[0]), TIPOS = ["0", "1", "2", "3"], run = async (a, e) => { const v = vals(e), f = e.target; if (await post(a, v)) { alert("Listo"); f.reset(); location.reload(); } };
  return (<><form className="card" onSubmit={(e) => run("addCasas", e)}><b>Lote de casas (un tipo, una región, muchos números)</b>
    <select name="tipo">{TIPOS.map((t) => <option key={t} value={t}>Casa tipo {t}</option>)}</select><input name="img" placeholder="Link de la imagen (Discord)" required /><input name="region" placeholder="Región (ej: Caracas)" required />
    <textarea name="numeros" rows={3} placeholder="Números de casa: 401, 402, 405-420 ..." required /><input name="price" type="number" min="0" placeholder="Precio" required /><input name="impuesto" type="number" min="0" placeholder="Impuesto mensual" /><Razon /><button className="btn"><Plus size={18} />Crear casas</button></form>
    <form className="card" style={{ marginTop: 12 }} onSubmit={(e) => run("editTipo", e)}><b>Editar casas por tipo (deja vacío lo que no cambia)</b><select name="tipo">{TIPOS.map((t) => <option key={t} value={t}>Casa tipo {t}</option>)}</select>
      <input name="region" placeholder="Solo esta región (opcional)" /><input name="img" placeholder="Nueva imagen (opcional)" /><input name="price" type="number" min="0" placeholder="Nuevo precio" /><input name="impuesto" type="number" min="0" placeholder="Nuevo impuesto mensual" /><Razon /><button className="btn">Aplicar a todas</button></form>
    <form className="card" style={{ marginTop: 12 }} onSubmit={(e) => run("addItem", e)}><b>Nuevo artículo del mercado</b>
      <select name="category" value={cat} onChange={(e) => setCat(e.target.value)}>{CATS.map((x) => <option key={x}>{x}</option>)}</select><input name="name" placeholder="Nombre" required /><input name="price" type="number" min="0" placeholder="Precio" required /><textarea name="desc" placeholder="Descripción" rows={2} />
      {cat === "Propiedades" && <><input name="ubicacion" placeholder="Ubicación (ej: Caracas 405)" required /><input name="impuesto" type="number" min="0" placeholder="Impuesto mensual" /></>}
      {cat === "Concesionario" && <><input name="clase" placeholder="Clase (ej: Deportivo, SUV)" /><input name="brand" placeholder="Marca / modelo" /><input name="year" placeholder="Año" /><input name="impuesto" type="number" min="0" placeholder="Impuesto" /></>}
      <input name="img" placeholder="URL de la foto (opcional)" /><input name="stock" type="number" min="1" placeholder="Stock (vacío = ilimitado)" /><Razon /><button className="btn"><Plus size={18} />Agregar</button></form>
    <div className="card" style={{ marginTop: 12 }}><b>Catálogo ({items.length})</b>{items.map((i) => <div key={i.id} style={{ display: "flex", justifyContent: "space-between", gap: 8, alignItems: "center", margin: "6px 0" }}><span>{i.name}{i.ubicacion ? ` · ${i.ubicacion}` : ""} <span className="mut">{i.category} · {$(i.price)}{i.impuesto ? ` · imp. ${$(i.impuesto)}` : ""}</span></span><span style={{ display: "flex", gap: 6 }}>
      <button className="btn g" onClick={async () => { const p = prompt("Nuevo precio (vacío = no cambia):", i.price); if (p === null) return; const m = prompt("Nuevo impuesto mensual (vacío = no cambia):", i.impuesto || ""); if (m === null) return; const r = ask("Razón del cambio:"); if (r && (await post("setPrice", { id: i.id, price: p, impuesto: m, razon: r }))) location.reload(); }}>Editar</button>
      <button className="btn g" onClick={async () => { const r = ask(`Razón para eliminar "${i.name}":`); if (r && (await post("delItem", { id: i.id, razon: r }))) location.reload(); }}><Trash2 size={16} /></button></span></div>)}</div></>);
}
function Apelaciones({ apelaciones }) {
  const dec = async (id, ok) => { const r = prompt(ok ? "Razón de la aprobación:" : "Razón de la denegación (se la mostramos al usuario):"); if (!r || r.trim().length < 3) return r !== null && alert("La razón es obligatoria"); if (await post(ok ? "apelOk" : "apelNo", { id, razon: r.trim() })) location.reload(); };
  return (<div className="card"><b>Apelaciones de CK ({apelaciones.length})</b><p className="mut">Personajes muertos por sed o hambre que piden volver (por ejemplo, por un corte de luz). Si aprueban, vuelve con comida y agua al 100%.</p>{apelaciones.map((r) => <div key={r.id} style={{ padding: "10px 0", borderTop: "1px solid var(--bd)" }}><div><b>{r.nombre}</b> · murió de {r.causa}</div><div className="mut">{new Date(r.at).toLocaleString("es")}</div><div style={{ margin: "6px 0" }}>{r.razon}</div>
    <div style={{ display: "flex", gap: 8 }}><button className="btn" onClick={() => dec(r.id, true)}>Aprobar</button><button className="btn r" onClick={() => dec(r.id, false)}>Denegar</button></div></div>)}{!apelaciones.length && <p className="mut">Sin apelaciones pendientes.</p>}</div>);
}
function Solicitudes({ robos }) {
  return (<div className="card"><b>Solicitudes de robo de autos ({robos.length})</b>{robos.map((r) => <div key={r.id} style={{ padding: "10px 0", borderTop: "1px solid var(--bd)" }}>
    <img src={r.img} alt="" style={{ width: "100%", maxWidth: 360, borderRadius: 10 }} /><div><b>{r.modelo}</b> · {r.color} · Placa {r.placa}</div><div className="mut">Solicita: {r.user}</div><div>{r.specs}</div>
    <div style={{ display: "flex", gap: 8, marginTop: 8 }}><button className="btn" onClick={async () => { if (await post("roboOk", { id: r.id })) location.reload(); }}><Check size={16} />Aprobar</button>
      <button className="btn r" onClick={async () => { const m = ask("Razón para rechazar:"); if (m && (await post("roboNo", { id: r.id, razon: m }))) location.reload(); }}><Trash2 size={16} />Rechazar</button></div></div>)}{!robos.length && <p className="mut">No hay solicitudes pendientes.</p>}</div>);
}
function Staff({ staff }) {
  return (<div className="card"><b>Staff de Administración</b><p className="mut">Solo quienes están aquí pueden entrar a Administración, y al entrar les pide su placa. Lo asignan el Developer, Fundación y Asuntos Internos. La persona debe haber iniciado sesión en el portal al menos una vez. Junta Directiva, Fundación y Asuntos Internos hacen todo; Moderador solo revisa solicitudes.</p>
    <form className="row2" onSubmit={async (e) => { const v = vals(e); if (await post("staffSet", v)) location.reload(); }}><input name="username" placeholder="Usuario de Discord" required /><select name="rango"><option value="JUNTA_DIRECTIVA">Junta Directiva</option><option value="FUNDACION">Fundación</option><option value="ASUNTOS_INTERNOS">Asuntos Internos</option><option value="MODERACION">Moderador</option></select><input name="placa" placeholder="Placa (obligatoria)" required /><button className="btn"><Plus size={16} />Asignar</button></form>
    {staff.map((x) => <div key={x.id} style={{ display: "flex", justifyContent: "space-between", gap: 8, padding: "8px 0", borderTop: "1px solid var(--bd)" }}><span><b>{x.name}</b> <span className="tag">{RANK_LABEL[x.rango] || x.rango}</span>{x.placa && <span className="mut"> · Placa {x.placa}</span>}</span>{x.rango !== "DEVELOPER" && <button className="btn r" onClick={async () => { if (confirm(`¿Quitar a ${x.name} del staff?`) && (await post("staffDel", { uid: x.id }))) location.reload(); }}><Trash2 size={14} /></button>}</div>)}{!staff.length && <p className="mut">Sin staff asignado.</p>}</div>);
}
function Apertura({ ultimo }) {
  const [nota, setNota] = useState(""), [busy, setBusy] = useState("");
  const ST = { votacion: ["🗳️ Votación abierta", "#60a5fa"], abrir: ["🟢 Servidor abierto", "#22c55e"], cerrar: ["🔴 Servidor cerrado", "#ef4444"] };
  const enviar = async (tipo, pregunta) => { if (!confirm(pregunta)) return; setBusy(tipo); const ok = await post("apertura", { tipo, nota }); setBusy(""); if (ok) { alert("Enviado a Discord"); location.reload(); } };
  const B = [["votacion", "🗳️ Abrir votación", "#2563eb", "¿Enviar la votación para abrir el servidor? Se menciona a Civil Venezolano."], ["abrir", "🟢 Abrir servidor", "#16a34a", "¿Anunciar que el servidor está ABIERTO? Se menciona a Civil Venezolano."], ["cerrar", "🔴 Cerrar servidor", "#dc2626", "¿Anunciar que el servidor está CERRADO?"]];
  return (<div className="card"><b>Apertura del servidor</b>
    <p className="mut">Envía un mensaje a Discord por el webhook de aperturas. La votación lleva encuesta (🟢 entro / 🟡 más tarde), el GIF y el ping a Civil Venezolano. Necesita la variable DISCORD_WEBHOOK_APERTURA en Vercel.</p>
    {ultimo && <div style={{ margin: "8px 0" }}>Último aviso: <b style={{ color: ST[ultimo.tipo]?.[1] }}>{ST[ultimo.tipo]?.[0]}</b> <span className="mut">· {ultimo.por} · {new Date(ultimo.at).toLocaleString("es")}</span></div>}
    <input value={nota} onChange={(e) => setNota(e.target.value)} maxLength={200} placeholder="Nota opcional (ej: código del servidor, hora de inicio...)" />
    <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(200px,1fr))", gap: 10, marginTop: 10 }}>{B.map(([k, t, c, q]) => <button key={k} className="btn" disabled={!!busy} style={{ background: c, padding: 16, fontSize: 16, fontWeight: 800 }} onClick={() => enviar(k, q)}>{busy === k ? "Enviando..." : t}</button>)}</div></div>);
}
function Erlc() {
  const [msg, setMsg] = useState("");
  return (<div className="card"><b>Conexión con ER:LC</b><p className="mut">Envía el comando <b>:h</b> (mensaje en pantalla) al servidor de ER:LC. Escribe el mensaje que quieres mostrar; si lo dejas vacío manda uno de prueba. Necesita la variable ERLC_SERVER_KEY en Vercel y al menos un jugador dentro del servidor. Cuando la MDT arresta a alguien con minutos, el portal le manda :jail a su usuario de Roblox.</p>
    <input value={msg} onChange={(e) => setMsg(e.target.value)} maxLength={100} placeholder="Mensaje para :h (opcional)" />
    <button className="btn" style={{ marginTop: 8 }} onClick={async () => { if (await post("erlcTest", { msg })) alert("Comando :h enviado. Revisa si el mensaje salió en el servidor de ER:LC."); }}>Probar conexión (enviar :h)</button></div>);
}
function AgenteForm() {
  const [dep, setDep] = useState(DEPTOS[1] || DEPTOS[0]);
  return (<form className="row2" onSubmit={async (e) => { const v = vals(e); if (await post("agenteSet", v)) location.reload(); }}><input name="username" placeholder="Usuario de Discord" required />
    <select name="depto" value={dep} onChange={(e) => setDep(e.target.value)}>{DEPTOS.map((d) => <option key={d}>{d}</option>)}</select>
    <select name="rango">{(RANGOS_POR_DEPTO[dep] || []).map((r) => <option key={r}>{r}</option>)}</select><input name="placa" placeholder="Placa" required /><button className="btn"><Plus size={16} />Asignar</button></form>);
}
function Agentes({ agentes }) {
  return (<div className="card"><b>Agentes de la MDT</b><p className="mut">Asigna a un policía con su departamento, rango y placa. El sueldo ya no se pone aquí: lo fija y lo libera el Ministro del Interior desde la Tesorería de la MDT. Al entrar a la MDT, solo le pedirá su placa. Desde "Comisario" aprueban allanamientos.</p>
    <AgenteForm />
    {agentes.map((x) => <div key={x.id} style={{ display: "flex", justifyContent: "space-between", gap: 8, padding: "8px 0", borderTop: "1px solid var(--bd)" }}><span><b>{x.rango}</b> {x.nombre || x.name}<div className="mut">@{x.name} · Placa {x.placa} · {x.depto}</div></span><button className="btn r" onClick={async () => { if (confirm(`¿Quitar a ${x.name} de la MDT?`) && (await post("agenteDel", { uid: x.id }))) location.reload(); }}><Trash2 size={14} /></button></div>)}{!agentes.length && <p className="mut">Aún no hay agentes asignados.</p>}</div>);
}
export default function Admin({ rank, items, reps, audit, robos = [], apertura = null, staff = [], agentes = [], canStaff = false, apelaciones = [] }) {
  const full = canAdmin(rank), TABS = full ? ["Usuarios", "Mercado", "Solicitudes", "Apelaciones", "Agentes MDT", "Auditoría", "Reportes 911", "ER:LC", "Apertura", ...(canStaff ? ["Staff"] : [])] : ["Solicitudes", "Apelaciones"];
  const [tab, setTab] = useState(full ? "Usuarios" : "Solicitudes");
  useEffect(() => { clearTimeout(window.__admOut); const out = () => navigator.sendBeacon("/api/admin/salir"); addEventListener("pagehide", out); return () => { removeEventListener("pagehide", out); window.__admOut = setTimeout(out, 400); }; }, []); // la sesión de Administración no se mantiene: al salir del panel hay que volver a poner la placa
  return (<div style={{ maxWidth: 900, margin: "0 auto" }}><img src="/admin-logo.jpg" alt="VE:RP" style={{ width: "min(380px,100%)", borderRadius: 12, display: "block", margin: "0 auto 8px" }} /><h2 style={{ textAlign: "center" }}>Administración Y Asuntos Internos De Venezuela Community</h2><span className="tag">{RANK_LABEL[rank] || rank}</span>
    <div style={{ display: "flex", gap: 8, margin: "12px 0", flexWrap: "wrap" }}>{TABS.map((t) => <button key={t} className={"btn " + (tab === t ? "" : "g")} onClick={() => setTab(t)}>{t}</button>)}</div>
    {tab === "Solicitudes" && <Solicitudes robos={robos} />}{tab === "Apelaciones" && <Apelaciones apelaciones={apelaciones} />}{tab === "Staff" && <Staff staff={staff} />}{tab === "Agentes MDT" && <Agentes agentes={agentes} />}{tab === "Usuarios" && <Usuarios items={items} />}{tab === "Mercado" && <Mercado items={items} />}
    {tab === "ER:LC" && <Erlc />}{tab === "Apertura" && <Apertura ultimo={apertura} />}
    {tab === "Auditoría" && <div className="card"><b>Registro de auditoría (últimas 100 acciones)</b>{audit.map((x) => <div key={x.id} style={{ padding: "8px 0", borderTop: "1px solid var(--bd)" }}><b>{x.act}</b> · {x.obj}<div className="mut">{x.by} ({String(x.rank).replace("_", " ")}) · {new Date(x.at).toLocaleString("es")}</div><div>Razón: {x.razon}</div></div>)}{!audit.length && <p className="mut">Sin registros.</p>}</div>}
    {tab === "Reportes 911" && <div className="card"><b>Reportes 911</b>{reps.map((r) => <div key={r.id} style={{ margin: "8px 0" }}>{r.t}<div className="mut">{r.d} · {r.e}</div><button className="btn g" onClick={async () => { if (await post("done", { id: r.id })) location.reload(); }}><Check size={16} className="neon" />Resuelto</button></div>)}{!reps.length && <p className="mut">Sin reportes pendientes.</p>}</div>}</div>);
}
