"use client";
import { useState, useEffect, useRef } from "react";
import { Send, Plus, ArrowLeft, MessageCircle, Repeat, EyeOff } from "lucide-react";
import { fmtTel } from "@/lib/redes";
import Estados from "./Estados";
import Av from "./Av";
export default function Chat() {
  const [d, setD] = useState({ yo: null, lista: [], chat: [] }), [sel, setSel] = useState(null), [txt, setTxt] = useState(""), [add, setAdd] = useState(false), [err, setErr] = useState(""), [nom, setNom] = useState(""), [tab, setTab] = useState("chats"), [menu, setMenu] = useState(false), [ahora, setAhora] = useState(Date.now()), end = useRef(null), selR = useRef(null);
  selR.current = sel;
  const load = async () => { const r = await fetch(`/api/wa?con=${encodeURIComponent(selR.current || "")}`); if (r.ok) setD(await r.json()); };
  useEffect(() => { const t = setInterval(() => !document.hidden && load(), 3000); return () => clearInterval(t); }, []);
  useEffect(() => { load(); }, [sel]);
  useEffect(() => { const t = setInterval(() => setAhora(Date.now()), 1000); return () => clearInterval(t); }, []);
  useEffect(() => { end.current?.scrollIntoView(); }, [d.chat.length]);
  const post = async (b) => { const r = await fetch("/api/wa", { method: "POST", body: JSON.stringify(b) }), j = await r.json().catch(() => ({})); setErr(r.ok ? "" : j.error || "Error"); await load(); return r.ok; };
  if (!d.yo) return <p className="mut">Cargando...</p>;
  const an = d.yo.modo === "anon", A = d.yo.anon, resto = A ? Math.max(0, +new Date(A.exp) - ahora) : 0, vivo = an && A && A.activa && resto > 0 && A.usos < A.max;
  const cuenta = async (b) => { await post(b); setSel(null); setMenu(false); };
  const Cambiar = d.yo.desechable ? (<div className="card" style={{ margin: 8, padding: 10, borderColor: an ? "#ff9f1a" : undefined }}>
    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 8, flexWrap: "wrap" }}><span>{an ? <b style={{ color: "#ff9f1a" }}><EyeOff size={14} /> Cuenta anónima</b> : <b>Mi cuenta</b>}</span><button className="btn g" style={{ padding: "5px 10px" }} onClick={() => setMenu(!menu)}><Repeat size={14} />Cambiar de cuenta</button></div>
    {an && <div className="mut" style={{ marginTop: 4 }}>{vivo ? `Quedan ${Math.floor(resto / 6e4)}:${String(Math.floor((resto % 6e4) / 1e3)).padStart(2, "0")} · ${A.max - A.usos} de ${A.max} usos` : "Sesión terminada (15 minutos o 5 usos)"}</div>}
    {menu && <div style={{ display: "grid", gap: 6, marginTop: 8 }}>{d.yo.tieneChip && <button className={"btn " + (an ? "g" : "")} onClick={() => cuenta({ accion: "modo", modo: "real" })}>Mi cuenta real</button>}
      <button className={"btn " + (an ? "" : "g")} onClick={() => (vivo ? cuenta({ accion: "modo", modo: "anon" }) : cuenta({ accion: "anon_nueva" }))}>{vivo ? "Cuenta anónima (activa)" : "Nueva cuenta anónima"}</button>
      <div className="mut" style={{ fontSize: 12 }}>La anónima usa un número falso que nadie puede rastrear. Cada sesión dura 15 minutos y tiene 5 usos (mensajes).</div></div>}</div>) : null;
  if (!d.yo.num) return (<div style={{ maxWidth: 420, margin: "0 auto" }}>{Cambiar}<div className="card"><b>{an ? "Sin cuenta anónima activa" : "Sin cuenta"}</b><p className="mut">{an ? "Tu sesión anónima terminó. Abre una nueva para seguir." : "Elige una cuenta."}</p>{err && <p style={{ color: "var(--bad)" }}>{err}</p>}{d.yo.desechable && <button className="btn" style={{ width: "100%" }} onClick={() => cuenta({ accion: "anon_nueva" })}>Nueva cuenta anónima</button>}</div></div>);
  if (!an && !d.yo.nombre) return (<form className="card" style={{ maxWidth: 380, margin: "0 auto" }} onSubmit={(e) => { e.preventDefault(); post({ accion: "perfil", nombre: nom }); }}><h3 style={{ margin: 0 }}>Bienvenido a VE WhatsApp</h3><p className="mut">Tu número es {fmtTel(d.yo.num)}. ¿Cómo quieres que te vean tus contactos?</p>
    <input value={nom} onChange={(e) => setNom(e.target.value)} maxLength={24} placeholder="Tu nombre o apodo" required />{err && <p style={{ color: "var(--bad)" }}>{err}</p>}<button className="btn" style={{ width: "100%" }}>Guardar</button></form>);
  const cur = d.lista.find((x) => x.num === sel), titulo = cur?.alias || d.nombre || (sel && fmtTel(sel));
  return (<div className={"wa" + (sel ? " sel" : "")}>
    <div className="wa-l">{Cambiar}<div className="wa-r" style={{ cursor: "default" }}><div style={{ display: "flex", gap: 10, alignItems: "center" }}><Av src={d.yo.foto} nombre={d.yo.nombre} size={40} /><div><b style={{ color: an ? "#ff9f1a" : "#12b886" }}>VE WhatsApp</b><div className="mut">{fmtTel(d.yo.num)} · {d.yo.nombre}</div></div></div>{!an && <button className="btn g" onClick={() => setAdd(!add)} aria-label="Agregar contacto"><Plus size={18} /></button>}{an && <button className="btn g" onClick={() => setAdd(!add)} aria-label="Escribir a un número"><Plus size={18} /></button>}</div>
      <div className="wa-r" style={{ cursor: "default", gap: 8 }}><button className={"btn " + (tab === "chats" ? "" : "g")} style={{ flex: 1 }} onClick={() => setTab("chats")}>Chats</button>{!an && <button className={"btn " + (tab === "estados" ? "" : "g")} style={{ flex: 1 }} onClick={() => setTab("estados")}>Estados</button>}</div>
      {tab === "estados" && !an ? <Estados /> : <>{add && <form className="wa-r" style={{ display: "grid", cursor: "default" }} onSubmit={async (e) => { e.preventDefault(); const f = e.target, v = Object.fromEntries(new FormData(f)); if (an) { const m = String(v.num || "").replace(/\D/g, "").replace(/^58/, "").replace(/^0/, ""); if (m.length === 10) { setSel("+58" + m); f.reset(); setAdd(false); } else setErr("Número inválido (ej: 0412 1234567)"); return; } if (await post({ accion: "contacto", ...v })) { f.reset(); setAdd(false); } }}>
        <input name="num" required placeholder="Número (0412 1234567)" />{!an && <input name="alias" maxLength={24} placeholder="Nombre del contacto" />}<button className="btn">{an ? "Escribir" : "Agregar"}</button></form>}
      {err && <p style={{ color: "var(--bad)", padding: "0 14px" }}>{err}</p>}
      {d.lista.map((x) => <div className="wa-r" key={x.num} onClick={() => setSel(x.num)} style={x.num === sel ? { background: "var(--bg)" } : null}><div style={{ display: "flex", gap: 10, alignItems: "center", minWidth: 0 }}><Av src={x.foto} nombre={x.alias} size={42} /><div style={{ minWidth: 0 }}><b>{x.alias}</b><div className="mut" style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{x.ultimo || "Sin mensajes"}</div></div></div>{x.sin > 0 && <span className="tag">{x.sin}</span>}</div>)}
      {!d.lista.length && <p className="mut" style={{ padding: 14 }}>Aún no tienes chats. Toca + y agrega un número.</p>}</>}</div>
    <div className="wa-c">{sel ? <><div className="wa-r" style={{ cursor: "default", justifyContent: "flex-start", alignItems: "center" }}><button className="btn g wa-back" onClick={() => setSel(null)} aria-label="Volver"><ArrowLeft size={18} /></button><Av src={cur?.foto || d.foto} nombre={titulo} size={36} /><b style={{ marginLeft: 8 }}>{titulo}</b></div>
      <div className="wa-m">{d.chat.map((m) => <div key={m.id} className={"wa-b" + (m.mio ? " me" : "")}>{m.texto}<div style={{ fontSize: 10, opacity: 0.6, textAlign: "right" }}>{new Date(m.at).toLocaleTimeString("es", { hour: "2-digit", minute: "2-digit" })}</div></div>)}<div ref={end} /></div>
      <form className="wa-i" onSubmit={async (e) => { e.preventDefault(); const t = txt; if (!t.trim()) return; setTxt(""); await post({ accion: "enviar", para: sel, texto: t }); }}><input value={txt} onChange={(e) => setTxt(e.target.value)} maxLength={500} placeholder={an ? (vivo ? "Mensaje anónimo (gasta 1 uso)" : "Sesión anónima terminada") : "Escribe un mensaje"} disabled={an && !vivo} style={{ flex: 1 }} /><button className="btn" aria-label="Enviar"><Send size={18} /></button></form></>
      : <div className="mut" style={{ margin: "auto", textAlign: "center" }}><MessageCircle size={48} /><p>Selecciona un chat</p></div>}</div></div>);
}
